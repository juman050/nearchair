<link rel="stylesheet" href="<?php echo base_url(); ?>resource/user/css/user.css">

<section class="userProfileHeaderSection">
    <div class="container">
        
        <div class="row">
            <div class="col-md-7 col-sm-7 col-xs-7">

                    <div class="left_div">
                        <h2 class="name"><?php echo $fullname; ?></h2>
                        <h3 class="mobile">

                            <span class="ripplelink">
                            <a href="javascript:void(0);" class="logout_icon" style="color: #ff546f;padding: 5px 6px;background: white;border-radius: 50%;font-size: 12px;margin-right: 8px;"><i class="fa fa-power-off" aria-hidden="true"></i></a>
                            </span>
                            <?php echo $userMobile; ?>
                        
                        </h3>
                    </div>

            </div>
            <div class="col-md-5 col-xs-5 col-xs-5">
                
                <div class="right_div">
                    <div class="avatar-upload">
                        <form enctype="multipart/form-data" id="changeProfilePic">
                        <div class="avatar-edit">
                            <input name="image" type='file' id="imageUpload" accept=".png, .jpg, .jpeg" required="required"/>
                            <label for="imageUpload"></label>
                        </div>
                        
                        <button type="submit" class="btn btn-xs change_btn">Change</button>
                        </form>
                        <div class="avatar-preview">
                            <?php if($userProfile[0]->image){ ?>
                            <div id="imagePreview" style="background-image: url(<?php echo '../drives/users/'.$userProfile[0]->image; ?>);">
                            <?php }else{ ?>
                            <div id="imagePreview" style="background-image: url(<?php echo '../drives/users/no-image.png'; ?>">
                            <?php } ?>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

<section class="userProfileMainSection">
    <div class="container">
        
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center custom_h2">Update Your Profile</h2>

                <form action="<?php echo base_url('app/changeProfile') ?>" method="POST" id="changeProfile">
                    
                    <div class="form-group">
                        <label for="fullname">Full Name</label>
                        <input type="text" class="form-control" id="fullname" name="fullname" required="required" value="<?php echo $userProfile[0]->fullname; ?>">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $userProfile[0]->email; ?>">
                    </div>
                    <div class="form-group">
                        <label for="number">Mobile Number</label>
                        <input type="text" class="form-control" id="number" name="number" value="<?php echo $userProfile[0]->mobile; ?>" disabled="true">
                    </div>
                    <div class="form-group">
                        <label for="city">City</label>
                        <select name="city" class="form-control get-area" id="city">
                            <?php if($cities): ?>
                            <?php foreach($cities as $city): ?>
                            <?php if($userProfile[0]->city!=0): ?>
                            <?php  if($city->city_id==1): ?>
                                <option <?php if($city->city_id == $userProfile[0]->city){ ?>selected="selected"<?php } ?> value="<?php echo $city->city_id; ?>"><?php echo $city->city_name; ?></option>
                            <?php  endif; ?>
                            <?php else: ?>
                            
                                <option value="<?php echo $city->city_id; ?>"><?php echo $city->city_name; ?></option>
                            <?php endif; ?>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="area">Area</label>
                        <select name="area" class="form-control append-option" id="area">
                            <option value="">Select Area</option>
                            <?php if($sylhet_areas): ?>
                            <?php foreach($sylhet_areas as $areas): ?>
                                <option <?php if($areas->area_id == $userProfile[0]->area){ ?>selected="selected"<?php } ?> value="<?php echo $areas->area_id; ?>"><?php echo $areas->area_name; ?></option>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea class="form-control" id="address" name="address" rows="8"><?php echo $userProfile[0]->address; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <p style="color: black;">Gender</p>
                        <label for="male"  class="radio-inline">
                            <input type="radio" name="gender" id="male" class="gender" value="1" <?php if($userProfile[0]->gender == 1){echo 'checked';} if($userProfile[0]->gender == ""){echo 'checked';}?> >Male
                        </label>
                        <label for="female"  class="radio-inline">
                            <input type="radio" name="gender" id="female" class="gender" value="2" <?php if($userProfile[0]->gender == 2){echo 'checked';} ?> >Female
                        </label>

                    </div>
                    <button class="btn btn-default changeProfile">Update</button>
                </form>

            </div>
        </div>

    </div>
</section>
<script>
jQuery(function($){
    
        // $('.get-area').change(function(){
        //     var city_id = $(this).val();
        //     $.ajax({
        //       type: 'POST',
        //       dataType: 'html',
        //       url: baseURL+'app/get_area_by_city',
        //       data: {city_id:city_id},
        //         success: function(response){
        //           $('.append-option').html(response);
        //       }
        //     });
        // })
        
        
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                    $('.change_btn').css('display', 'block');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#imageUpload").change(function() {
            readURL(this);
        });


        if ($("#changeProfilePic").length > 0) {
            $("#changeProfilePic").validate({
              
            rules: {
                imageUpload: {
                     required: true,
                },
               
            },
            messages: {
                imageUpload: {
                    required:"Choose a image",
                }, 
              
            },
            submitHandler: function(form) {
                var formData = new FormData($('#changeProfilePic')[0]);
                $.ajax({
                   type: 'POST',
                   dataType: 'json',
                   url: baseURL+'app/changeProfilePic',
                   data: formData,
                    contentType: false,
                    processData: false,
                    beforeSend: function() { $.LoadingOverlay("show"); },
                    complete: function() { $.LoadingOverlay("hide"); },
                    success: function(response){
                       
                       $('#success_tic').modal('show');
                       $('#success_tic').find('.head-text').html(response.msg);
                    //   $('#changeProfilePic')[0].reset();
                       $('.change_btn').css('display', 'none');
                   }
                });
            }
          })
        }
        
        
        if ($("#changeProfile").length > 0) {
            $("#changeProfile").validate({
              
            rules: {
                fullname: {
                     required: true,
                },
                city: {
                     required: true,
                     number: true,
                },
                address: {
                     required: true,
                },
                gender: {
                     required: true,
                     number: true,
                },
               
            },
            messages: {   
                fullname: {
                    required:"Full Name must be fillup!",
                },  
                city: {
                    required:"City Must Be Select",
                     number: "Something is wrong",
                },  
                address: {
                    required:"Please Enter Your Address",
                },  
                gender: {
                    required:"Select Your Gender",
                     number: "Something is wrong",
                },
              
            },
            submitHandler: function(form) {
                $.ajax({
                  type: 'POST',
                  dataType: 'json',
                  url: baseURL+'app/updateUserProfile',
                  data: $('#changeProfile').serialize(),
                    beforeSend: function() { $.LoadingOverlay("show"); },
                    complete: function() { $.LoadingOverlay("hide"); },
                    success: function(response){
                       $('.name').html($("input[name=fullname]").val());
                       $('#success_tic').find('.head-text').html(response.msg);
                       $('#success_tic').modal('show');
                  }
                });
            }
          })
        }

        $(".logout_icon").on("click",function(){
            $('#modallogout').modal('show');
        });
        
        
    });


</script>


<!-- Modal -->
<div id="success_tic" class="modal fade" role="dialog">
    <div class="modal-dialog">

    <!-- Modal content-->
        <div class="modal-content">
            <a class="close" href="#" data-dismiss="modal">&times;</a>
            <div class="page-body">
                <div class="head">  
                    <h3 style="margin-top:5px;" class="head-text">Password Changes Successfully</h3>
                </div>
    
                <h1 style="text-align:center;">
                <div class="checkmark-circle">
                    <div class="background"></div>
                    <div class="checkmark draw"></div>
                </div>
                <h1>
    
            </div>
        </div>
    </div>

</div>

    
    
<!--Modal: modallogout-->
<div class="modal fade" id="modallogout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-sm modal-notify modal-danger  modal-dialog-centered" role="document">
    <!--Content-->
    <div class="modal-content text-center">
      <!--Header-->

      <div class="modal-header d-flex justify-content-center">
        <p class="heading">Are you sure ?</p>      
      </div>

      <!--Body-->
      <div class="modal-body">

        <h3 class="text-center">Want to Logout ?</h3> 

      </div>

      <!--Footer-->
      <div class="modal-footer flex-center">
        <a href="<?php echo base_url('app/logoutUser'); ?>" class="btn  btn-outline-danger flat-icon waves-effect waves-light">Yes</a>
        <a type="button" class="btn  btn-danger flat-icon waves-effect" data-dismiss="modal">No</a>
      </div>

    </div>
    <!--/.Content-->
  </div>
</div>

<!--Modal: modallogout-->
