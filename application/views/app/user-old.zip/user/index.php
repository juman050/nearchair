<link rel="stylesheet" href="<?php echo base_url(); ?>resource/user/css/user.css">

<section class="userProfileHeaderSection">
    <div class="container">
        
        <div class="row">
            <div class="col-md-7 col-sm-7 col-xs-7">

                    <div class="left_div">
                        <h2 class="name"><?php echo $fullname; ?></h2>
                        <h3 class="mobile">

                            <span class="ripplelink">
                            <a href="javascript:void(0);" class="logout_icon" style="color: #ff546f;padding: 5px 6px;background: white;border-radius: 50%;font-size: 12px;margin-right: 8px;"><i class="fa fa-power-off" aria-hidden="true"></i></a>
                            </span>
                            <?php echo $userMobile; ?>
                        
                        </h3>
                        
                    </div>

            </div>
            <div class="col-md-5 col-xs-5 col-xs-5">
                
                <div class="right_div">
                    <div class="avatar-upload">
                        <form enctype="multipart/form-data" id="changeProfilePic">
                        <div class="avatar-edit">
                            <input name="image" type='file' id="imageUpload" accept=".png, .jpg, .jpeg" required="required"/>
                            <label for="imageUpload"></label>
                        </div>
                        
                        <button type="submit" class="btn btn-xs change_btn">Change</button>
                        </form>
                        <div class="avatar-preview">
                            <?php if($userProfile[0]->image){ ?>
                            <div id="imagePreview" style="background-image: url(<?php echo '../drives/users/'.$userProfile[0]->image; ?>);">
                            <?php }else{ ?>
                            <div id="imagePreview" style="background-image: url(<?php echo '../drives/users/no-image.png'; ?>">
                            <?php } ?>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<section class="userProfileMainSection">
    <div class="container">
        
        <div class="row">
            <div class="col-md-12">

                
                <div class="main-box-div">
                    
                    <a href="<?php echo base_url('app/userProfileView'); ?>">
                        <div class="single-box-div ripplelink">
                            <img src="<?php echo base_url() ?>resource/user/images/users.png"/>
                            <p>Profile</p>
                        </div>
                    </a>
                    <a href="<?php echo base_url('app/userProfileOrderList'); ?>">
                        <div class="single-box-div ripplelink">
                            <img src="<?php echo base_url() ?>resource/user/images/order.png"/>
                            <p>Orders</p>
                        </div>
                    </a>
                    <a href="<?php echo base_url('app/userProfileChangePassword'); ?>">
                        <div class="single-box-div ripplelink">
                            <img src="<?php echo base_url() ?>resource/user/images/settings.png"/>
                            <p>Change Password</p>
                        </div>
                    </a>
                    <a href="tel:01746150145">
                        <div class="single-box-div ripplelink">
                            <img src="<?php echo base_url() ?>resource/user/images/customer-service.png"/>
                            <p>Support</p>
                        </div>
                    </a>
                    
                </div>
                
                
            </div>
        </div>

    </div>
</section>

<script>
    jQuery(function($){
    
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                    $('.change_btn').css('display', 'block');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#imageUpload").change(function() {
            readURL(this);
        });


        if ($("#changeProfilePic").length > 0) {
            $("#changeProfilePic").validate({
              
            rules: {
                imageUpload: {
                     required: true,
                },
               
            },
            messages: {
                imageUpload: {
                    required:"Choose a image",
                }, 
              
            },
            submitHandler: function(form) {
                var formData = new FormData($('#changeProfilePic')[0]);
                $.ajax({
                   type: 'POST',
                   dataType: 'json',
                   url: baseURL+'app/changeProfilePic',
                   data: formData,
                    contentType: false,
                    processData: false,
                    beforeSend: function() { $.LoadingOverlay("show"); },
                    complete: function() { $.LoadingOverlay("hide"); },
                    success: function(response){
                       $('#success_tic').modal('show');
                       $('#success_tic').find('.head-text').html(response.msg);
                       $('#changeProfilePic')[0].reset();
                       $('.change_btn').css('display', 'none');
                   }
                });
            }
          })
        }

        $(".logout_icon").on("click",function(){
            $('#modallogout').modal('show');
        });

    });


</script>


<!-- Modal -->
<div id="success_tic" class="modal fade" role="dialog">
    <div class="modal-dialog">

    <!-- Modal content-->
        <div class="modal-content">
            <a class="close" href="#" data-dismiss="modal">&times;</a>
            <div class="page-body">
                <div class="head">  
                    <h3 style="margin-top:5px;" class="head-text">Password Changes Successfully</h3>
                </div>
    
                <h1 style="text-align:center;">
                <div class="checkmark-circle">
                    <div class="background"></div>
                    <div class="checkmark draw"></div>
                </div>
                <h1>
    
            </div>
        </div>
    </div>

</div>


    
<!--Modal: modallogout-->
<div class="modal fade" id="modallogout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-sm modal-notify modal-danger  modal-dialog-centered" role="document">
    <!--Content-->
    <div class="modal-content text-center">
      <!--Header-->

      <div class="modal-header d-flex justify-content-center">
        <p class="heading">Are you sure ?</p>      
      </div>

      <!--Body-->
      <div class="modal-body">

        <h3 class="text-center">Want to Logout ?</h3> 

      </div>

      <!--Footer-->
      <div class="modal-footer flex-center">
        <a href="<?php echo base_url('app/logoutUser'); ?>" class="btn  btn-outline-danger flat-icon waves-effect waves-light">Yes</a>
        <a type="button" class="btn  btn-danger flat-icon waves-effect" data-dismiss="modal">No</a>
      </div>

    </div>
    <!--/.Content-->
  </div>
</div>

<!--Modal: modallogout-->

