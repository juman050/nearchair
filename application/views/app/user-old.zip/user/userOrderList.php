<link rel="stylesheet" href="<?php echo base_url(); ?>resource/user/css/user.css">
<style>
    

.tblTH {
    color: #222222 !important;
    border: none !important;
    font-size: 16px;
    font-weight: 500;
}
.tblTD {
    color: #616161 !important;
    border: none !important;
    font-size: 15px;
} 
.i_style {
    background: #ff546f;
    padding: 5px;
    border-radius: 50%;
    color: white;
    font-size: 12px;
} 
</style>
<section class="userProfileHeaderSection">
    <div class="container">
        
        <div class="row">
            <div class="col-md-7 col-sm-7 col-xs-7">

                    <div class="left_div">
                        <h2 class="name"><?php echo $fullname; ?></h2>
                        <h3 class="mobile">

                            <span class="ripplelink">
                            <a href="javascript:void(0);" class="logout_icon" style="color: #ff546f;padding: 5px 6px;background: white;border-radius: 50%;font-size: 12px;margin-right: 8px;"><i class="fa fa-power-off" aria-hidden="true"></i></a>
                            </span>
                            <?php echo $userMobile; ?>
                        
                        </h3>
                    </div>

            </div>
            <div class="col-md-5 col-xs-5 col-xs-5">
                
                <div class="right_div">
                    <div class="avatar-upload">
                        <form enctype="multipart/form-data" id="changeProfilePic">
                        <div class="avatar-edit">
                            <input name="image" type='file' id="imageUpload" accept=".png, .jpg, .jpeg" required="required"/>
                            <label for="imageUpload"></label>
                        </div>
                        
                        <button type="submit" class="btn btn-xs change_btn">Change</button>
                        </form>
                        <div class="avatar-preview">
                            <?php if($userProfile[0]->image){ ?>
                            <div id="imagePreview" style="background-image: url(<?php echo '../drives/users/'.$userProfile[0]->image; ?>);">
                            <?php }else{ ?>
                            <div id="imagePreview" style="background-image: url(<?php echo '../drives/users/no-image.png'; ?>">
                            <?php } ?>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<section class="userProfileMainSection">
    <div class="container">
        
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center custom_h2">Recent Orders</h2>
                
                <table class="table ordersTable">
                      <th scope="col" class="tblTH">#</th>
                      <th scope="col" class="tblTH">Business Name</th>
                      <th scope="col" class="tblTH">Price</th>
                      <th scope="col" class="text-center tblTH">View</th>
                    </tr>
                  </thead>
                  <tbody>
    
                    <?php
                    
                    if($userOrders):
                        $count = 0;
                        $totalOrder = 0;
                        foreach($userOrders as $order):
                            $totalOrder = +$order->order_total + $totalOrder;
                    
                    ?>
                    <tr>
                      <th scope="row" class="tblTD"><?php echo ++$count; ?></th>
                      <td class="tblTD"><?php echo $order->business_name; ?></td>
                      <td class="tblTD"><?php echo +$order->order_total; ?></td>
                      <td class="text-center tblTD">
                            <a href="javascript:void(0)" data-order_id="<?php echo $order->order_id; ?>" class="view_order ripplelink">
                                <i class="fa fa-eye i_style"></i>
                            </a>
                      </td>
                    </tr>
                    
                    <?php endforeach; ?>
                    
                    <tr style="border-top: 1px solid #c9c9c9;">
                      <th colspan="2" class="tblTD">Total Order</th>
                      <td colspan="2" class="tblTD"><?php echo $totalOrder; ?></td>
                    </tr>
                    
                    <?php
                    else:
                    
                    ?>
                    
                    <tr>
                      <td class="text-center" colspan="4">No Order Yet</td>
                    </tr>
                    
                    <?php endif; ?>
                    
                  </tbody>
                </table>  
            
                <br>
                <br>
            
            
            </div>
        
        


    </div>
</section>
           

<script>
    jQuery(function($){
    
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                    $('.change_btn').css('display', 'block');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#imageUpload").change(function() {
            readURL(this);
        });


        if ($("#changeProfilePic").length > 0) {
            $("#changeProfilePic").validate({
              
            rules: {
                imageUpload: {
                     required: true,
                },
               
            },
            messages: {
                imageUpload: {
                    required:"Choose a image",
                }, 
              
            },
            submitHandler: function(form) {
                var formData = new FormData($('#changeProfilePic')[0]);
                $.ajax({
                   type: 'POST',
                   dataType: 'json',
                   url: baseURL+'app/changeProfilePic',
                   data: formData,
                    contentType: false,
                    processData: false,
                    beforeSend: function() { $.LoadingOverlay("show"); },
                    complete: function() { $.LoadingOverlay("hide"); },
                    success: function(response){
                       $('#success_tic').modal('show');
                       $('#success_tic').find('.head-text').html(response.msg);
                       $('#changeProfilePic')[0].reset();
                       $('.change_btn').css('display', 'none');
                   }
                });
            }
          })
        }

        $(".view_order ").on("click",function(){
            var order_id = $(this).data('order_id');
            
            $.ajax({
               type: 'POST',
               dataType: 'html',
               url: baseURL+'app/singleOrderDetails',
               data: {order_id:order_id},
                beforeSend: function() { $.LoadingOverlay("show"); },
                complete: function() { $.LoadingOverlay("hide"); },
                success: function(response){
                    $('#modalDetails').find('.modal_order_id').text(order_id);
                    $('#singleOrderDetails').html(response);
                    $('#modalDetails').modal('show');
               }
            });
            
            
            
            
            
            
            
        });

        $(".logout_icon").on("click",function(){
            $('#modallogout').modal('show');
        });

    });


</script>

<!-- Modal -->
<div id="success_tic" class="modal fade" role="dialog">
    <div class="modal-dialog">

    <!-- Modal content-->
        <div class="modal-content">
            <a class="close" href="#" data-dismiss="modal">&times;</a>
            <div class="page-body">
                <div class="head">  
                    <h3 style="margin-top:5px;" class="head-text">Password Changes Successfully</h3>
                </div>
    
                <h1 style="text-align:center;">
                <div class="checkmark-circle">
                    <div class="background"></div>
                    <div class="checkmark draw"></div>
                </div>
                <h1>
    
            </div>
        </div>
    </div>

</div>

    
    
<!--Modal: modallogout-->
<div class="modal fade" id="modallogout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-sm modal-notify modal-danger  modal-dialog-centered" role="document">
    <!--Content-->
    <div class="modal-content text-center">
      <!--Header-->

      <div class="modal-header d-flex justify-content-center">
        <p class="heading">Are you sure ?</p>      
      </div>

      <!--Body-->
      <div class="modal-body">

        <h3 class="text-center">Want to Logout ?</h3> 

      </div>

      <!--Footer-->
      <div class="modal-footer flex-center">
        <a href="<?php echo base_url('app/logoutUser'); ?>" class="btn  btn-outline-danger flat-icon waves-effect waves-light">Yes</a>
        <a type="button" class="btn  btn-danger flat-icon waves-effect" data-dismiss="modal">No</a>
      </div>

    </div>
    <!--/.Content-->
  </div>
</div>

<!--Modal: modallogout-->

    
<!--Modal: modalDetails-->
<div class="modal fade" id="modalDetails" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-sm modal-notify modal-danger  modal-dialog-centered" role="document">
    <!--Content-->
    <div class="modal-content text-center">
      <!--Header-->

      <div class="modal-header d-flex justify-content-center">
        <p class="heading">Details of order id : <span class="modal_order_id"></span></p> 
      </div>

      <!--Body-->
      <div class="modal-body" id="singleOrderDetails">

        

      </div>

      <!--Footer-->
      <div class="modal-footer flex-center">
        <a type="button" class="btn  btn-danger flat-icon rippleLink" data-dismiss="modal">Close</a>
      </div>

    </div>
    <!--/.Content-->
  </div>
</div>

<!--Modal: modalDetails-->