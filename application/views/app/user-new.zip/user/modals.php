<!-- Success Error Modal -->
<div id="success_tic" class="modal fade" role="dialog">
    <div class="modal-dialog">
    <!-- Modal content-->
        <div class="modal-content">
            <a class="close" href="#" data-dismiss="modal">&times;</a>
            <div class="page-body">
                <div class="head">  
                    <h3 style="margin-top:5px;" class="head-text">Password Changes Successfully</h3>
                </div>
                <h1 style="text-align:center;">
                    <div class="checkmark-circle">
                        <div class="background"></div>
                        <div class="checkmark draw"></div>
                    </div>
                </h1>
            </div>
        </div>
    </div>
</div>


<!-- Modal: View Order Modal -->
<div class="modal fade" id="modalDetails" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-notify modal-danger  modal-dialog-centered" role="document">
        <div class="modal-content text-center">
            <div class="modal-header d-flex justify-content-center">
                <p class="heading">Details of order id : <span class="modal_order_id"></span></p> 
            </div>
            <div class="modal-body" id="singleOrderDetails"></div>
    
            <div class="modal-footer flex-center">
                <a type="button" class="btn  btn-danger flat-icon rippleLink" data-dismiss="modal">Close</a>
            </div>
        </div>
    </div>
</div>

<!--Modal: View Order Modal-->
    
<!--Modal: Logout Modal -->
<div class="modal fade" id="modallogout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-notify modal-danger  modal-dialog-centered" role="document">
        <div class="modal-content text-center">
        
            <div class="modal-header d-flex justify-content-center">
                <p class="heading">Are you sure ?</p>      
            </div>
            <div class="modal-body">
                <h3 class="text-center">Want to Logout ?</h3> 
            </div>
            <div class="modal-footer flex-center">
                <a href="<?php echo base_url('app/logoutUser'); ?>" class="btn  btn-outline-danger flat-icon waves-effect waves-light">Yes</a>
                <a type="button" class="btn  btn-danger flat-icon waves-effect" data-dismiss="modal">No</a>
            </div>
        
        </div>
    </div>
</div>
<!--Modal: Logout Modal-->