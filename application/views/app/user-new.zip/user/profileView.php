<link rel="stylesheet" href="<?php echo base_url(); ?>resource/user/css/user.css">
<section class="userProfileHeaderSection">
    <div class="container">
        <div class="row">
            
            <div class="col-md-7 col-sm-7 col-xs-7">
                <div class="left_div">
                    <h2 class="name"><?php echo $fullname; ?></h2>
                    <h3 class="mobile"><span class="ripplelink"><a href="javascript:void(0);" class="logout_icon" style="color: #ff546f;padding: 5px 6px;background: white;border-radius: 50%;font-size: 12px;margin-right: 8px;"><i class="fa fa-power-off" aria-hidden="true"></i></a></span><?php echo $userMobile; ?></h3>
                </div>
            </div>
            <div class="col-md-5 col-xs-5 col-xs-5">
                <div class="right_div">
                    <div class="avatar-upload">
                        <form enctype="multipart/form-data" id="changeProfilePic">
                            <div class="avatar-edit">
                                <input name="image" type='file' id="imageUpload" accept=".png, .jpg, .jpeg" required="required"/>
                                <label for="imageUpload"></label>
                            </div>
                            <button type="submit" class="btn btn-xs change_btn">Change</button>
                        </form>
                        <div class="avatar-preview"><?php if($userProfile[0]->image){ ?><div id="imagePreview" style="background-image: url(<?php echo '../drives/users/'.$userProfile[0]->image; ?>);"></div><?php }else{ ?><div id="imagePreview" style="background-image: url(<?php echo '../drives/users/no-image.png'; ?>"></div><?php } ?></div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

<section class="userProfileMainSection">
    <div class="container">
        <div class="row">
            
            <div class="col-md-12">
                <h2 class="text-center custom_h2">Update Your Profile</h2>
                <form action="<?php echo base_url('app/changeProfile') ?>" method="POST" id="changeProfile">
                    
                    <div class="form-group">
                        <label for="fullname">Full Name</label>
                        <input type="text" class="form-control" id="fullname" name="fullname" required="required" value="<?php echo $userProfile[0]->fullname; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $userProfile[0]->email; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="number">Mobile Number</label>
                        <input type="text" class="form-control" id="number" name="number" value="<?php echo $userProfile[0]->mobile; ?>" disabled="true">
                    </div>
                    
                    <div class="form-group">
                        <label for="city">City</label>
                        <select name="city" class="form-control get-area" id="city">
                            <?php if($cities): ?>
                            <?php foreach($cities as $city): ?>
                            <?php if($userProfile[0]->city!=0): ?>
                            <?php  if($city->city_id==1): ?>
                                <option <?php if($city->city_id == $userProfile[0]->city){ ?>selected="selected"<?php } ?> value="<?php echo $city->city_id; ?>"><?php echo $city->city_name; ?></option>
                            <?php  endif; ?>
                            <?php else: ?>
                                <option value="<?php echo $city->city_id; ?>"><?php echo $city->city_name; ?></option>
                            <?php endif; ?>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="area">Area</label>
                        <select name="area" class="form-control append-option" id="area">
                            <option value="">Select Area</option>
                            <?php if($sylhet_areas): ?>
                            <?php foreach($sylhet_areas as $areas): ?>
                                <option <?php if($areas->area_id == $userProfile[0]->area){ ?>selected="selected"<?php } ?> value="<?php echo $areas->area_id; ?>"><?php echo $areas->area_name; ?></option>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea class="form-control" id="address" name="address" rows="8"><?php echo $userProfile[0]->address; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <p style="color: black;">Gender</p>
                        <label for="male"  class="radio-inline">
                            <input type="radio" name="gender" id="male" class="gender" value="1" <?php if($userProfile[0]->gender == 1){echo 'checked';} if($userProfile[0]->gender == ""){echo 'checked';}?> >Male
                        </label>
                        <label for="female"  class="radio-inline">
                            <input type="radio" name="gender" id="female" class="gender" value="2" <?php if($userProfile[0]->gender == 2){echo 'checked';} ?> >Female
                        </label>
                    </div>
                    
                    <button class="btn btn-default changeProfile">Update</button>
                </form>
            </div>
            
        </div>
    </div>
</section>

<script src="<?php echo base_url(); ?>resource/user/js/user.js" type="text/javascript"></script>

<?php $this->load->view('app/user/modals'); ?>