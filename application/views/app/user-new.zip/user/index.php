<link rel="stylesheet" href="<?php echo base_url(); ?>resource/user/css/user.css">
<section class="userProfileHeaderSection">
    <div class="container">
        <div class="row">
            
            <div class="col-md-7 col-sm-7 col-xs-7">
                <div class="left_div">
                    <h2 class="name"><?php echo $fullname; ?></h2>
                    <h3 class="mobile"><span class="ripplelink"><a href="javascript:void(0);" class="logout_icon" style="color: #ff546f;padding: 5px 6px;background: white;border-radius: 50%;font-size: 12px;margin-right: 8px;"><i class="fa fa-power-off" aria-hidden="true"></i></a></span><?php echo $userMobile; ?></h3>
                </div>
            </div>
            <div class="col-md-5 col-xs-5 col-xs-5">
                <div class="right_div">
                    <div class="avatar-upload">
                        <form enctype="multipart/form-data" id="changeProfilePic">
                            <div class="avatar-edit">
                                <input name="image" type='file' id="imageUpload" accept=".png, .jpg, .jpeg" required="required"/>
                                <label for="imageUpload"></label>
                            </div>
                            <button type="submit" class="btn btn-xs change_btn">Change</button>
                        </form>
                        <div class="avatar-preview"><?php if($userProfile[0]->image){ ?><div id="imagePreview" style="background-image: url(<?php echo '../drives/users/'.$userProfile[0]->image; ?>);"></div><?php }else{ ?><div id="imagePreview" style="background-image: url(<?php echo '../drives/users/no-image.png'; ?>"></div><?php } ?></div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

<section class="userProfileMainSection">
    <div class="container">
        <div class="row">
            
            <div class="col-md-12">
                <div class="main-box-div">
                    <a href="<?php echo base_url('app/userProfileView'); ?>">
                        <div class="single-box-div ripplelink"><img src="<?php echo base_url() ?>resource/user/images/users.png"/><p>Profile</p></div>
                    </a>
                    <a href="<?php echo base_url('app/userProfileOrderList'); ?>">
                        <div class="single-box-div ripplelink">
                            <img src="<?php echo base_url() ?>resource/user/images/order.png"/>
                            <p>Orders</p>
                        </div>
                    </a>
                    <a href="<?php echo base_url('app/userProfileChangePassword'); ?>">
                        <div class="single-box-div ripplelink">
                            <img src="<?php echo base_url() ?>resource/user/images/settings.png"/>
                            <p>Change Password</p>
                        </div>
                    </a>
                    <a href="tel:01746150145">
                        <div class="single-box-div ripplelink">
                            <img src="<?php echo base_url() ?>resource/user/images/customer-service.png"/>
                            <p>Support</p>
                        </div>
                    </a>
                </div>
            </div>
            
        </div>
    </div>
</section>

<script src="<?php echo base_url(); ?>resource/user/js/user.js" type="text/javascript"></script>

<?php $this->load->view('app/user/modals'); ?>