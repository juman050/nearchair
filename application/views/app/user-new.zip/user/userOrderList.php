<link rel="stylesheet" href="<?php echo base_url(); ?>resource/user/css/user.css">
<section class="userProfileHeaderSection">
    <div class="container">
        <div class="row">
            
            <div class="col-md-7 col-sm-7 col-xs-7">
                <div class="left_div">
                    <h2 class="name"><?php echo $fullname; ?></h2>
                    <h3 class="mobile"><span class="ripplelink"><a href="javascript:void(0);" class="logout_icon" style="color: #ff546f;padding: 5px 6px;background: white;border-radius: 50%;font-size: 12px;margin-right: 8px;"><i class="fa fa-power-off" aria-hidden="true"></i></a></span><?php echo $userMobile; ?></h3>
                </div>
            </div>
            <div class="col-md-5 col-xs-5 col-xs-5">
                <div class="right_div">
                    <div class="avatar-upload">
                        <form enctype="multipart/form-data" id="changeProfilePic">
                            <div class="avatar-edit">
                                <input name="image" type='file' id="imageUpload" accept=".png, .jpg, .jpeg" required="required"/>
                                <label for="imageUpload"></label>
                            </div>
                            <button type="submit" class="btn btn-xs change_btn">Change</button>
                        </form>
                        <div class="avatar-preview"><?php if($userProfile[0]->image){ ?><div id="imagePreview" style="background-image: url(<?php echo '../drives/users/'.$userProfile[0]->image; ?>);"></div><?php }else{ ?><div id="imagePreview" style="background-image: url(<?php echo '../drives/users/no-image.png'; ?>"></div><?php } ?></div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>

<section class="userProfileMainSection">
    <div class="container">
        <div class="row">
            
            <div class="col-md-12">
                <h2 class="text-center custom_h2">Recent Orders</h2>
                <table class="table ordersTable">
                      <th scope="col" class="tblTH">#</th>
                      <th scope="col" class="tblTH">Business Name</th>
                      <th scope="col" class="tblTH">Price</th>
                      <th scope="col" class="text-center tblTH">View</th>
                    </tr>
                  </thead>
                  <tbody><?php
                    
                    if($userOrders):
                        $count = 0;
                        $totalOrder = 0;
                        foreach($userOrders as $order):
                            $totalOrder = +$order->order_total + $totalOrder;
                    
                    ?><tr>
                      <th scope="row" class="tblTD"><?php echo ++$count; ?></th>
                      <td class="tblTD"><?php echo $order->business_name; ?></td>
                      <td class="tblTD"><?php echo +$order->order_total; ?></td>
                      <td class="text-center tblTD">
                            <a href="javascript:void(0)" data-order_id="<?php echo $order->order_id; ?>" class="view_order ripplelink">
                                <i class="fa fa-eye i_style"></i>
                            </a>
                      </td>
                    </tr>
                    
                    <?php endforeach; ?>
                    
                    <tr style="border-top: 1px solid #c9c9c9;">
                      <th colspan="2" class="tblTD">Total Order</th>
                      <td colspan="2" class="tblTD"><?php echo $totalOrder; ?></td>
                    </tr>
                    
                    <?php else: ?>
                    
                    <tr>
                      <td class="text-center" colspan="4">No Order Yet</td>
                    </tr>
                    
                    <?php endif; ?>
                  </tbody>
                </table>  
                <br>
                <br>
            </div>

        </div>
    </div>
</section>
           
<script src="<?php echo base_url(); ?>resource/user/js/user.js" type="text/javascript"></script>

<?php $this->load->view('app/user/modals'); ?>