<table class="table ordersTable">
    <tbody>
    
        <tr>
            <td class="tblTD">Customer Name</td>
            <td class="tblTD"><?php echo $userOrders[0]->fullname; ?></td>
        </tr>
        <tr>
            <td class="tblTD">Gender</td>
            <td class="tblTD"><?php echo $userOrders[0]->gender; ?></td>
        </tr>
        <tr>
            <td class="tblTD">User Email</td>
            <td class="tblTD"><?php echo $userOrders[0]->user_email; ?></td>
        </tr>
        <tr>
            <td class="tblTD">User Number</td>
            <td class="tblTD"><?php echo $userOrders[0]->user_mobile; ?></td>
        </tr>
        <tr>
            <td class="tblTD">User Address</td>
            <td class="tblTD"><?php echo $userOrders[0]->user_address; ?></td>
        </tr>
        <tr>
            <td class="tblTD">Order Date</td>
            <td class="tblTD"><?php echo date( 'M d, Y h:i a',strtotime($userOrders[0]->order_date)); ?></td>
        </tr>

        <tr>
            <td class="tblTD">Order Type</td>
            <td class="tblTD"><?php echo ($userOrders[0]->order_type==0) ? 'Now' : (($userOrders[0]->order_type==1) ? 'Advanced' : 'Unknown'); ?></td>
        </tr>
        
        <?php 
        
            if($userOrderServices){
                foreach($userOrderServices as $services){
        ?>

        <tr>
            <td class="tblTD">Service</td>
            <td class="tblTD"><?php echo $services->service_name.' ( '.$services->service_price.' )'; ?></td>
        </tr>
        
        <?php
                }
            }
        ?>
        <?php
            if($userOrderAdvanced){
                foreach($userOrderAdvanced as $advanced){
        ?>

        <tr>
            <td class="tblTD">Appoinment Start</td>
            <td class="tblTD"><?php echo date( 'M d, Y h:i a',strtotime($advanced->appointment_start)); ?></td>
        </tr>
        <tr>
            <td class="tblTD">Appoinment End</td>
            <td class="tblTD"><?php echo date( 'M d, Y h:i a',strtotime($advanced->appointment_end)); ?></td>
        </tr>
        
        <?php
                }
            }
            
        ?>
        
        
        
        
        <tr>
            <td class="tblTD">Order Total</td>
            <td class="tblTD"><?php echo $userOrders[0]->order_total; ?></td>
        </tr>
        <tr>
            <td class="tblTD">Payment</td>
            <td class="tblTD"><?php echo ($userOrders[0]->payment_method=='cod') ? 'Cash On Delivery' : 'Online'; ?></td>
        </tr>
        <tr>
            <td class="tblTD">Order Status</td>
            <td class="tblTD"><?php echo ($userOrders[0]->order_status==0) ? 'Pending' : (($userOrders[0]->order_status==1) ? 'Accepted' : (($userOrders[0]->order_status==2) ? 'Cancelled' : 'Unknown')); ?></td>
        </tr>
        <tr>
            <td class="tblTD">City</td>
            <td class="tblTD"><?php echo $userOrders[0]->city_name; ?></td>
        </tr>
   </tbody>
</table>