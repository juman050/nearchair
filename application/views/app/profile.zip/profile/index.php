<script type="text/javascript" src="<?php echo base_url(); ?>/resource/owner/js/pages/profile.js"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>resource/owner/css/ownerProfile.css">
    <!--++++++++++ main-Panel ++++++++++-->
    <section id="main-panel">
        <?php if(!empty($allbusinesses)): ?>
        <div class="container business-status-panel">
            <div class="row">
                <div class="col-xs-12 text-center">
                    <p class="maintain_txt">Manage Your Business</p>
                </div>
                <div class="col-xs-12 text-center">
                    
                <div class="container">
                  <label class="switch" for="checkbox">
                    <input type="checkbox" id="checkbox" class="business_status" <?php if($allbusinesses[0]->business_on_off == 1){echo 'checked';}  ?>/>
                    <div class="slider_switdh round"></div>
                  </label>
                </div>

                <script type="text/javascript">
                    var var_business_id = '<?php echo $allbusinesses[0]->business_id;  ?>';
                    jQuery(function($){
                
                        $('.business_status').on('change',function(){
                            var status = $('#checkbox').prop('checked');
                            if(status===true){
                                var sts = 1;
                            }else{
                                var sts = 0;
                            }
                
                            if(var_business_id)
                            {
                                $.ajax({
                                    url: "<?php echo site_url('app/change_business_status');?>",
                                    dataType: 'html',
                                    method: 'POST',
                                    data: {'sts':sts,'business_id':var_business_id},
                                    success: function(data){
                                        $('.turn_status').html(data);
                                    }
                
                                });
                            }
                
                        });
                
                    });
                </script>
                </div>
                <div class="col-xs-12 text-center">
                    <p class="turn_status text-center" ><?php if($allbusinesses[0]->business_on_off == 1){echo 'Turn Off';}else{{echo 'Turn On';}}  ?></p>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </section>
        

    <section class="home-page-gategory-section" style="margin-bottom: 40px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-heading">
                    <?php
                        $error = $this->session->flashdata('success_msg');
                        if($error):
                    ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo $this->session->flashdata('success_msg'); ?>                    
                        </div>
                    <?php 
                        endif;
                        $success = $this->session->flashdata('error_msg');
                        if($success):
                    ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo $this->session->flashdata('error_msg'); ?>                    
                        </div>
                    <?php endif; ?>
                    <?php $this->load->helper('form'); ?>
                    <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">

                <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                    <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="headingThree">
                            <h4 class="panel-title waves-effect waves-float">
                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseThree">
                                    <i class="fa fa-shopping-cart back_icon"></i>
                                    <i class="more-less glyphicon glyphicon-plus"></i>
                                    Orders
                                </a>
                            </h4>
                        </div>
                        <div id="collapseFour" class="panel-collapse collapse  text-center" role="tabpanel" aria-labelledby="headingThree">
                            <div class="panel-body">
                                <?php if(!empty($allbusinesses)): ?>
                                    <table class="table ordersTable">
                                          <th scope="col" class="tblTH">#</th>
                                          <th scope="col" class="tblTH">Customer Name</th>
                                          <th scope="col" class="tblTH">Price</th>
                                          <th scope="col" class="text-center tblTH">View</th>
                                        </tr>
                                      </thead>
                                      <tbody><?php
                                        
                                        if($userOrders):
                                            $count = 0;
                                            $totalOrder = 0;
                                            foreach($userOrders as $order):
                                                $totalOrder = +$order->order_total + $totalOrder;
                                        
                                        ?><tr>
                                          <th scope="row" class="tblTD"><?php echo ++$count; ?></th>
                                          <td class="tblTD"><?php echo $order->fullname; ?></td>
                                          <td class="tblTD"><?php echo +$order->order_total; ?></td>
                                          <td class="text-center tblTD">
                                                <a href="javascript:void(0)" data-order_id="<?php echo $order->order_id; ?>" class="view_order ripplelink">
                                                    <i class="fa fa-eye i_style"></i>
                                                </a>
                                          </td>
                                        </tr>
                                        
                                        <?php endforeach; ?>
                                        
                                        <tr style="border-top: 1px solid #c9c9c9;">
                                          <th colspan="2" class="tblTD">Total Order</th>
                                          <td colspan="2" class="tblTD"><?php echo $totalOrder; ?></td>
                                        </tr>
                                        
                                        <?php else: ?>
                                        
                                        <tr>
                                          <td class="text-center" colspan="4">No Order Yet</td>
                                        </tr>
                                        
                                        <?php endif; ?>
                                      </tbody>
                                    </table>
                                <?php else: ?>
                                    <p class="text-center">Your Business Is Pending Yet</p>
                                <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                    <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="headingOne">
                            <h4 class="panel-title waves-effect waves-float">
                                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne" >
                                    <i class="fa fa-info back_icon"></i>
                                    <i class="more-less glyphicon glyphicon-plus"></i>
                                    Business Info

                                </a>
                            </h4>
                        </div>
                        <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                            <div class="panel-body">
                                <?php if(!empty($allbusinesses)): ?>
                                    <form enctype="multipart/form-data" id="businessForm" >

                                      <div class="form-group">
                                        <label for="name">Business Name</label>

                                        <input type="hidden" name="business_id" id="business_id" class="form-control" value="<?php echo $allbusinesses[0]->business_id;  ?>">

                                        <input type="text" name="business_name" id="name" class="form-control" value="<?php echo $allbusinesses[0]->business_name;  ?>" required="required">
                                      </div>

                                      <div class="form-group">
                                        <label for="business_img">Image</label>
                                        <input type="file" name="business_img" class="form-control" id="business_img">

                                        <?php if($allbusinesses[0]->business_img): ?>
                                        <img src="<?php echo site_url().'drives/business/'.$allbusinesses[0]->business_img; ?>"  class="img-middle"  id="image-id"  />
                                        <?php else: ?>
                                            <img id="image-id"  class="img-middle"  />
                                        <?php endif; ?>

                                      </div>

                                      <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea  rows="8" id="description" name="business_description" class="form-control"><?php echo $allbusinesses[0]->business_description;  ?></textarea>
                                      </div>

                                      <div class="form-group">
                                        <label for="city">City</label>
                                        <select id="city" name="city_id" class="form-control" required="required">
                                            <?php foreach ($allCities as $cities) { ?>
                                            <option <?php if($cities->city_id == $allbusinesses[0]->city_id){echo 'selected';} ?> value="<?php echo $cities->city_id; ?>"><?php echo $cities->city_name; ?></option>
                                            <?php } ?>
                                        </select>
                                        
                                      </div>

                                      <div class="form-group">
                                        <label for="address">Address</label>
                                        <input type="text" id="address" name="address" class="form-control" value="<?php echo $allbusinesses[0]->address;  ?>"  required="required">
                                        
                                      </div>

                                      <div class="form-group">
                                        <label for="email">Business Email</label>
                                        <input disabled="true" type="email" id="email" name="email" class="form-control" value="<?php echo $allbusinesses[0]->email;  ?>"  required="required">
                                        
                                      </div>

                                      <div class="form-group">
                                        <label for="mobile_number">Mobile Number</label>
                                        <input type="number" id="mobile_number" name="mobile" class="form-control" value="<?php echo $allbusinesses[0]->mobile_number;  ?>"  required="required">
                                      </div>

                                      <div class="form-group">
                                        <label for="total_chairs">Total Chairs</label>
                                        <input type="text" id="total_chairs" name="total_chairs" class="form-control" value="<?php echo $allbusinesses[0]->total_chairs;  ?>"  required="required">
                                      </div>


                                      <div class="form-group">
                                        <label for="postal_code">Post Code</label>
                                        <input type="text" id="postal_code" name="postal_code" class="form-control" value="<?php echo $allbusinesses[0]->postal_code;  ?>"  required="required">
                                        
                                      </div>

                                      <div class="form-group">
                                        <label for="email">Joining Date</label>
                                        <input disabled="true" type="text" class="form-control" value="<?php echo date( 'M d, Y h:i a',strtotime($allbusinesses[0]->createdDtm));  ?>">
                                        
                                      </div>

                                      <div class="form-group">
                                        
                                        <button type="submit" class="btn btn-default addBusiness">Submit</button>
                                        
                                      </div>


                                    </form>
                                <?php else: ?>
                                    <p class="text-center">Your Business Is Pending Yet</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="serviceList">
                            <h4 class="panel-title waves-effect waves-float">
                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseService" aria-expanded="false" aria-controls="collapseService">
                                    <i class="fa fa-list back_icon"></i>
                                    <i class="more-less glyphicon glyphicon-plus"></i>
                                    Service List
                                </a>
                            </h4>
                        </div>
                        <?php if(!empty($seviceCategory)): ?>
                        <div id="collapseService" class="panel-collapse collapse" role="tabpanel" aria-labelledby="serviceList">
                            <div class="panel-body" id="service_list">


                            </div>
                        </div>
                        <?php else: ?>
                            <p class="text-center">No Data</p>
                        <?php endif; ?>
                    </div>
                        
                    <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="headingTwo">
                            <h4 class="panel-title waves-effect waves-float">
                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    <i class="fa fa-plus back_icon"></i>
                                    <i class="more-less glyphicon glyphicon-plus"></i>
                                    Add Service
                                </a>
                            </h4>
                        </div>
                        <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                            <div class="panel-body">
                                <?php if(!empty($allbusinesses)): ?>
                                <form id="serviceForm">

                                  <input type="hidden" name="business_id" id="business_id" class="form-control" value="<?php echo $allbusinesses[0]->business_id;  ?>" required="required">

                                  <div class="form-group">
                                    <label for="service_name">Name</label>
                                    <input type="text" class="form-control" id="service_name" name="service_name" required="required">
                                  </div>

                                  <div class="form-group">
                                    <label for="cat_id">Category</label>
                                    <select class="form-control" id="cat_id" name="cat_id" required="required">
                                        <option value="">Select Category</option>
                                        <?php 

                                            if($allcategories){
                                                foreach ($allcategories as $category) { ?>

                                                    <option value="<?=$category->category_id?>"><?=$category->category_name?></option>
                                            
                                        <?php
                                                }
                                            }

                                        ?>
                                    </select>
                                  </div>
                                  <div class="form-group">
                                    <label for="service_price">Price</label>
                                    <input type="text" class="form-control" id="service_price" name="service_price" required="required">
                                  </div>
                                  <div class="form-group">
                                    <label for="service_discount_price">Discount Price</label>
                                    <input type="text" class="form-control" id="service_discount_price" name="service_discount_price">
                                  </div>

                                  <div class="form-group">
                                    <label for="service_description">Description</label>
                                    <textarea rows="7" class="form-control" id="service_description" name="service_description"></textarea>
                                  </div>

                                  <div class="form-group">
                                    <label for="service_time_hr">Service Time</label>
                                    
                                    <select style="width: 30%;display: inline-block;" class="form-control" id="service_time_hr" name="service_time_hr" required="required">
                                        <option value="">Hr</option>
                                        <?php for($i=0;$i<24;$i++){ 

                                                if($i<10){
                                                  $count = 0;
                                                }else{
                                                  $count="";
                                                }

                                            ?>
                                            <option value="<?php echo $count.$i; ?>"><?php echo $count.$i; ?></option>
                                        <?php } ?>
                                        
                                    </select>
                                    <select style="width: 30%;display: inline-block;" class="form-control" id="service_time_min" name="service_time_min" required="required">
                                        <option value="">Min</option>
                                        <?php for($j=0;$j<60;$j++){ 

                                                if($j<10){
                                                  $count2 = 0;
                                                }else{
                                                  $count2="";
                                                }

                                            ?>
                                            <option value="<?php echo $count2.$j; ?>"><?php echo $count2.$j; ?></option>
                                        <?php } ?>
                                    </select>
                                  </div>
                                    
                                  <button class="btn float-button-light waves-effect waves-button waves-float waves-light add_service" style="background: #1bb556;color:white;">Submit</button>
                                </form>
                                <?php else: ?>
                                    <p class="text-center">Your Business Is Pending Yet</p>
                                <?php endif; ?>   
                            </div>
                        </div>
                    </div>

                    <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="headingThree">
                            <h4 class="panel-title waves-effect waves-float">
                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    <i class="fa fa-image back_icon"></i>
                                    <i class="more-less glyphicon glyphicon-plus"></i>
                                    Gallery
                                </a>
                            </h4>
                        </div>
                        <div id="collapseThree" class="panel-collapse collapse  text-center" role="tabpanel" aria-labelledby="headingThree">
                            <div class="panel-body">
                                <?php if(!empty($allbusinesses)): ?>
                                <div class="form-group">
                                    <?php if($allbusinesses[0]->gallery_image): ?>
                                        <div class="col-sm-12">
                                            <?php foreach($allbusinesses[0]->gallery_image as $gallery): ?>
                                            <div class="gallery-img-wrap">
                                                <span class="delete_gallery_image image-<?php echo $gallery->gallery_id; ?>" data-gallery_id="<?php echo $gallery->gallery_id; ?>">&times;</span>

                                                <img class="image-<?php echo $gallery->gallery_id; ?>" src="<?php echo site_url().'resource/app/images/gallery/'.$gallery->image; ?>" id="gallery_image-id" width="115px" />
                                            </div>
                                            
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <form enctype="multipart/form-data" class="form-inline" style="border-top: 1px solid #3e3535;padding-top: 20px;" id="galleryForm">
                                    <div class="form-group">
                                        <div class="col-sm-12">

                                            <input style="width: 75%;float: left;" type="file" class="form-control" id="gallery_image" name="gallery_image[]" multiple="multiple" id="gallery_image" required="required">

                                            <input type="hidden" class="form-control" name="business_id" id="business_id" required="required" value="<?php echo $allbusinesses[0]->business_id; ?>">

                                            <button type="submit" name="ADD" class="btn btn-sm btn-success pull-right">ADD</button>
                                            

                                        </div>
                                    </div>
                                </form>
                                <?php else: ?>
                                    <p class="text-center">Your Business Is Pending Yet</p>
                                <?php endif; ?>
                        </div>
                    </div>
                </div>


                </div><!-- panel-group -->

            </div>
        </div>
    </div>
</section>


<!-- Modal: View Order Modal -->
<div class="modal fade" id="modalDetails" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-notify modal-danger  modal-dialog-centered" role="document">
        <div class="modal-content text-center">
            <div class="modal-header d-flex justify-content-center">
                <p class="heading">Details of order id : <span class="modal_order_id"></span></p> 
            </div>
            <div class="modal-body" id="singleOrderDetails"></div>
    
            <div class="modal-footer flex-center">
                <a type="button" class="btn  btn-danger flat-icon rippleLink" data-dismiss="modal">Close</a>
            </div>
        </div>
    </div>
</div>
<!--Modal: View Order Modal-->